#ifndef INCLUDE_H
#define INCLUDE_H

#include <windows.h>

#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <io.h>

#include <omp.h>

#include "Config.h"
#include "Def.h"
#include "raytrace.h"
#include "Scene.h"
#include "SimpleString.h"

#endif